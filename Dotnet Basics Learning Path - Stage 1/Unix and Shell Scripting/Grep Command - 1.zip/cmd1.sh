grep ';' employee.txt
