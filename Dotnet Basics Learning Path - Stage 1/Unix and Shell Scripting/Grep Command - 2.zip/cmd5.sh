grep -v ';' employee.txt
