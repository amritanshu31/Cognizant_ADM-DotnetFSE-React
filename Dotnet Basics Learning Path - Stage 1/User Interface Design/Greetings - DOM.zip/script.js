function display()
{
var name;
var course;
name=document.getElementById("sname").value;
course=document.getElementById("course").value;
if(name===''){
document.getElementById("greet").innerHTML="Name cannot be empty";
}
else{
document.getElementById("greet").innerHTML="Hi," +name+". You have successfully registered for the " +course+" course.";
}
}