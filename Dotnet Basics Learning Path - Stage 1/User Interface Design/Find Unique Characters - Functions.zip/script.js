function modifyString(str)
{
for(var i=0;i<str.length;i++)
{
    if(str.includes(" ")) 
    {
        str=str.replace(" ","");
    }
}
var res=str.toLowerCase();
return res;

}


function uniqueCharacters(str)
{
//fill code here
var res="";
for(var i=0 ;i<str.length;i++)
{
    if(res.includes(str[i])===false)
    {
        res+=str[i];
    }
    
}
return modifyString(res);
}  

