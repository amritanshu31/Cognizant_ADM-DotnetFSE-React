function OrderCake(str) {
	//fill the code
	weight=str.substr(0,4);
	orderId=str.substr(str.length-3,3);
	flavour=str.slice(4,-3);
	weightInKgs=Math.round(weight/1000);
	cost=Math.round((weight/1000)*450);
	return 'Your order for '+weightInKgs+' kg '+flavour+' cake has been taken. You are requested to pay Rs. '+cost+' on the order no '+orderId;
	
}
console.log(OrderCake("5848ButterBlast485"));
