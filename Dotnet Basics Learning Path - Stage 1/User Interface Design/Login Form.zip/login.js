//WRITE YOUR JQUERY CODE HERE
$("#signup_div").css({'display':'none'});
$('#signup').on("click",function(){
    $("#signup_div").css({'display':'block'});   
});
