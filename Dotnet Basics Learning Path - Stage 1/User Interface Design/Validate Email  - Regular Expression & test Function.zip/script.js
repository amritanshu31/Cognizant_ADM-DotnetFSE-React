function validateEmail(email) 
{
        //fill the code
        var regexp = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
        if(regexp.test(String(email).toLowerCase()))
        {
            return "Valid email address!";
        }
        else{
            return "Invalid email address!";
       }
    }

