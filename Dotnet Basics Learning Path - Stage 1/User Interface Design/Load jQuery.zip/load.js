//WRITE YOUR jQUERY CODE HERE
$(document).ready(function(){
 $("#msg").html("<h2>jQuery is loaded!!!</h2>");
});
 