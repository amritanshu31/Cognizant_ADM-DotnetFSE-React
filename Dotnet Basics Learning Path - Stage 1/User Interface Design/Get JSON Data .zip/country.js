$('#btn-id').click(function(event){
$.getJSON("https://reqres.in/api/users?page=2",function(event){$('#data-id').append("<ul id='newList'></ul>");
$.each(event.data,function(key,value){
$("#newList").append("<li>"+value.id+" -- "+value.email+"</li>");
});
})
})