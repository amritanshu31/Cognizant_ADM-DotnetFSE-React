$("th").css("background-color","lightpink");
$("caption").css("background-color","lightblue");
$("tr").eq(1).css("background-color","lightblue");
$("tr").eq(2).css("background-color","lightpink");
$("tr").eq(3).css("background-color","lightblue");
$("tr").eq(4).css("background-color","lightpink");
$("tr").eq(0).css("background-color","lightpink");