$("#each_ex").click(function(event){
// alert("hii");
$("li").each(function(){
var li=$(this).text();
$('#msg_ex').append("<br>"+li);
$('.men_ex ul li a').css("backgroundColor","red")
console.log(li);
});
})