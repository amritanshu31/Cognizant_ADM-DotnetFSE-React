
    var myarr = [];
    var str = 'Successfully Added Feedback Details!';
function addFeedback(){

    document.getElementById('result').innerHTML = "";

    var inputtext = document.getElementById('feedback').value;
    myarr.push(inputtext);
    document.textform.feedback.value="";
    document.getElementById('result').innerHTML += str;
    

    

 }

function displayFeedback(){
        document.getElementById('result').innerHTML = "";
    document.getElementById('result').innerHTML = "Feedback Details <br>";

    for(var i = 0;i<myarr.length;i++){
     document.getElementById('result').innerHTML += 'Feedback' + ' ' + parseInt(i+1);
     document.getElementById('result').innerHTML += "<br>"+ myarr[i];
     document.getElementById('result').innerHTML += "<br>";    
     document.getElementById('result').style.border = "thick solid black";
     }
     myarr.length = 0;
}

