$('#button1').click(function(){
    $("#DAI").css( "background", "yellow" );
    $("#ASI").css( "background", "yellow" );
});