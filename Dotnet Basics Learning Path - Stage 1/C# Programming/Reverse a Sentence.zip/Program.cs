using System;

public class Program      //DO NOT change the class name
{
    static void Main(string[] args)
    {
    Console.WriteLine("Enter a string");
    string strings=Console.ReadLine();
    stringreverse(strings.ToCharArray());
    }
   static void stringreverse(char[] strline)
    {
        int len=(strline.Length)-1;
        string reverse="";
        int start=len;
        for(int i=len;i>=0;i--)
        {
            if(i==0||strline[i-1]==' ')
            {
            for(int j=i;j<=start;j++)
            {
            reverse +=strline[j];
            }
            reverse+=" ";
            start=i-2;
            i--;
            }
        }
        Console.WriteLine(reverse);
    }
}
