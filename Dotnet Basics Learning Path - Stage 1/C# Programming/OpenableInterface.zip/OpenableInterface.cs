using System;
public interface IOpenable{
    string OpenSesame();
}

public class TreasureBox:IOpenable{
    public string OpenSesame(){
        return "Congratulations , Here is your lucky win";
    }
}

public class Parachute:IOpenable{
    public string OpenSesame(){
        return "Have a thrilling experience flying in air";
    }
}

public class Program{
    public static void Main(string [] args){
        Console.WriteLine("Enter the letter found in the paper");
        string letter = Console.ReadLine();
        if(letter == "T"){
            TreasureBox tbox = new TreasureBox();
            Console.WriteLine(tbox.OpenSesame());
        }
        else{
            Parachute pr = new Parachute();
            Console.WriteLine(pr.OpenSesame());
        }
    }
}