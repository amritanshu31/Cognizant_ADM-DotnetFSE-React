using System;

public class Program  //DO NOT change the class name
{
    public static void Main(string[] args)
    {
        Console.WriteLine("Enter the value for x");
        int x=Convert.ToInt32(Console.ReadLine());
        Console.WriteLine("Enter the value for y");
        int y=Convert.ToInt32(Console.ReadLine());
        Console.Write("x is less than y  is "+(x<y));

    }
    
    //implement code here
}
