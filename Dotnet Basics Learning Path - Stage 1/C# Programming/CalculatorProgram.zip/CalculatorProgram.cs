using System;
public class Calculator 
{
    public int Addition(int a, int b)
    {
        return(a+b);
     }
    public int Subtraction(int a, int b)
        {
            return (a-b);
        }
    public int Multiplication(int a, int b)
        {
                return (a*b);
        }
    public double Division(int a, int b, out double remainder)
         {
              remainder=(a%b);
              return (a/b);
         }
}
 
public class Program 
{
    static void Main(string [] args)
    {
        Calculator ob =new Calculator();
       Console.WriteLine("Enter the operator");
       string a=Console.ReadLine();
       Console.WriteLine("Enter the operands");
       int num1=Int32.Parse(Console.ReadLine());
       int num2=Int32.Parse(Console.ReadLine());
       //double remainder=0.0;
       if(a=="+")
       {
           Console.WriteLine("Result of "+num1+" + "+num2+" is "+ob.Addition(num1,num2));
       }
       else if(a=="-")
       {
           Console.WriteLine("Result of "+num1+" - "+num2+" is "+ob.Subtraction(num1,num2));
       }
       else if(a=="*")
       {
           Console.WriteLine("Result of "+num1+" * "+num2+" is "+ob.Multiplication(num1,num2));
       }
       else if(a=="/")
       {
           Console.WriteLine("Result of "+num1+" / "+num2+" is "+ob.Division(num1,num2,out double remainder));
           Console.WriteLine("Remainder ="+remainder);
       }
       else
       {
           Console.WriteLine("Invalid Operator");
       }
}
}