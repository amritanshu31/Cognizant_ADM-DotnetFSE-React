using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DateEx1              //DO NOT CHANGE the namespace name
{
    public class Program       //DO NOT CHANGE the class name
    {
        public static void Main(string[] args)    //DO NOT CHANGE the 'Main' method signature
        {
            string dob;
            Console.WriteLine("Enter the date of birth (dd-mm-yyyy): ");
            dob=Console.ReadLine();
            Console.WriteLine(calculateAge(dob));
            //Implement code here
        }

        public static int calculateAge(string dateOfBirth)
        {
            //Implement code here
            DateTime today = DateTime.Now;
            int year = DateTime.Now.Year;
            
            int length=dateOfBirth.Length;
            string dcs = dateOfBirth.Substring(6,4);//year from dateOfBirth
            string csd=dateOfBirth.Substring(3,2);//month from dateOfBirth
            int age2=int.Parse(csd);
            if(age2>=6)
            {
                int age=int.Parse(dcs);
                int age1=(year-1)-age;
                return age1;
            }
            else
            {
                int age=int.Parse(dcs);
                int age3=(year)-age;
                return age3-1;
            }
        }


    }
}
