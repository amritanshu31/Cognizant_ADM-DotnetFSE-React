using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgFundamentals2  //DO NOT change the namespace name
{
    public class Program      //DO NOT change the class name
    {
        public static void Main(string[] args)     //DO NOT change the 'Main' method signature
        {
            //Implement the code here
            int no_pizza,no_puffs,no_pepsi;
            int cost_pizza,cost_puffs,cost_pepsi;
            int total_cost;
            double GST,CESS;
            
            int costperpizza=200,costperpuffs=40,costperpepsi=120;
            
            Console.WriteLine("Enter the number of pizzas bought:");
            no_pizza=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number of puffs bought:");
            no_puffs=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the number of pepsi bought:");
            no_pepsi=Convert.ToInt32(Console.ReadLine());
            
            cost_pizza=costperpizza*no_pizza;
            cost_puffs=costperpuffs*no_puffs;
            cost_pepsi=costperpepsi*no_pepsi;
            total_cost=cost_pizza+cost_puffs+cost_pepsi;
            GST=0.12*total_cost;
            CESS=0.05*total_cost;
            
            Console.WriteLine("Bill Details");
            
            Console.WriteLine("Cost of Pizzas : "+ cost_pizza);
            //cost_pizza=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Cost of Puffs : "+ cost_puffs);
            //cost_puffs=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Cost of Pepsis : "+cost_pepsi);
           // cost_pepsi=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("GST 12% : "+GST);
           // GST=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("CESS 5% : "+CESS);
           // CESS=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Total Price : "+total_cost);
           // total_cost=Convert.ToInt32(Console.ReadLine());
            
        }
    }
}
