using System;

public class Program      //DO NOT change the class name
{
    //implement code here
    static void Main(string[] args)
    {
        Console.WriteLine("Enter first name");
        string fullName = Console.ReadLine();
        Console.WriteLine("Enter last name");
        fullName += " " +Console.ReadLine();
        Console.WriteLine("Full name: " + fullName);
    }
}
