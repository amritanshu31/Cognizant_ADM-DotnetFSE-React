using System;


namespace JaggedArray      //DO NOT Change the namespace name
{
    public class Program    //DO NOT Change the class name
    {
        public static void Main(string[] args)    //DO NOT change the method signature
        {
	        //Implement code here
	        // Get input from the user and construct a jagged array 
	        int teams;
	        
	        Console.WriteLine("Enter the number of teams:");
	        teams = Convert.ToInt32(Console.ReadLine());
	        
	        int[] attempt = new int[teams];
	        
	        for(int i = 0; i < teams; i++)
	        {
	            Console.WriteLine("No.of attempts for team " + (i+1) + ":");
	            attempt[i] = Convert.ToInt32(Console.ReadLine());
	        }
	        int max_attempt = attempt[0];
	        for(int i = 0; i <teams; i++)
	        {
	            if(attempt[i] > max_attempt)
	            {
	                max_attempt = attempt[i];
	            }
	        }
	        
	        int[][] score_board = new int[teams][];
	       
	        for(int i = 0; i <teams; i++)
	        {
	            Console.WriteLine("Enter the score for team " + (i+1) +":");
	            score_board[i] = new int[attempt[i]];
	            for(int j = 0; j < attempt[i]; j++)
	            {
	                score_board[i][j] = Convert.ToInt32(Console.ReadLine());
	            }
	        }
	        
	        Console.WriteLine(GetTotalScore(score_board));
        }
        
        public static String GetTotalScore(int[][] score)        //DO NOT change the method signature
        {
            //Implement code here 
            //Method to calculate total score for each team and return a string as specified in the sample output.
            string result = "";
            int sum;
            for(int i = 0; i < score.Length; i++)
            {
                sum = 0;
                for(int j = 0; j <score[i].Length; j++)
                {
                    sum += score[i][j];
                }
                result += "Team " + (i+1) + " Total Score is " + sum + ". ";
            }
            return result;
        }

    }
}
