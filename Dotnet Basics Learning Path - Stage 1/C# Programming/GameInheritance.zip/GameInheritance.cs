using System;
public class Game
    {
        public string Name { get; set; }
        public int MaxNumPlayers { get; set; }
        public override string ToString()
        {
            string str = $"Maximum number of players for {Name} is {MaxNumPlayers}";
            return str;
        }
    }
    public class GameWithTimeLimit : Game
    {
        public int TimeLimit { get; set; }
        public override string ToString()
        {
            Game g = new Game();
            g.ToString();
            string str = $"Time Limit for {Name} is {TimeLimit} minutes";
            
            return str;
        }
    }
public class Program {
    public static void Main(string[] args){
        Game g = new Game();
    GameWithTimeLimit game = new GameWithTimeLimit();
            Console.WriteLine("Enter a game");
            string name = Console.ReadLine();
            g.Name = name;
            Console.WriteLine("Enter the maximum number of players");
            int player = int.Parse(Console.ReadLine());
            g.MaxNumPlayers = player;
            Console.WriteLine("Enter a game that has time limit");
            string gamename = Console.ReadLine();
            game.Name = gamename;
            Console.WriteLine("Enter the maximum number of players");
            int players = int.Parse(Console.ReadLine());
            game.MaxNumPlayers = players;
            Console.WriteLine("Enter the time limit in minutes");
            int TimeLimit = int.Parse(Console.ReadLine());
            game.TimeLimit = TimeLimit;
            Console.WriteLine(g.ToString());
            Console.WriteLine(game.ToString());
    }
}