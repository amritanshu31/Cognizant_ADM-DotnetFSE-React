INSERT INTO Department (department_id, department_name, department_block_number) VALUES (1,'CSE', 3);
INSERT INTO Department (department_id, department_name, department_block_number) VALUES (2,'IT', 3);
INSERT INTO Department (department_id, department_name, department_block_number) VALUES (3,'SE', 3);