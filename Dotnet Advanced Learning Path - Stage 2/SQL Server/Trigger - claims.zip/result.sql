create trigger claim_audits
on dbo.claims
for insert
as
declare @name varchar(30)
declare @total_amount varchar(25)
select @name=(select c.first_name 
    from customer c 
    join customer_policy cp
    on c.id=cp.customer_id 
    join claims cl 
    on cp.id=cl.customer_policy_id,inserted i 
    where cl.id=i.id)
select @total_amount=(select cl.amount_of_claim +i.amount_of_claim+50000 
    from inserted i, claims cl 
    join customer_policy cp 
    on cl.customer_policy_id=cp.id 
    where i.id=cl.id)
--select @total_amount=(select premium_amount from customer_policy)
insert into dbo.claim_audit(customer_name,amount_of_claim,action) select @name,@total_amount,'Updated customer claimed amount';
GO