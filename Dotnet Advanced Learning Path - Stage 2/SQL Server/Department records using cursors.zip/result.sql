DECLARE 
    @dept_name VARCHAR(MAX),
    @empcount varchar(max);
DECLARE dpt_cur CURSOR FOR
    SELECT count(e.workdept),d.deptname
    FROM Department d join Employee e
    on d.deptno=e.workdept
    group by e.workdept,d.deptname
    order by d.deptname;
OPEN dpt_cur;
FETCH NEXT FROM dpt_cur INTO 
    @empcount,
    @dept_name;
WHILE @@FETCH_STATUS = 0
    BEGIN
    if (@empcount>1)
        PRINT @dept_name+" department has "+cast(@empcount as varchar)+" employees ";
        FETCH NEXT FROM dpt_cur INTO 
            @empcount,
            @dept_name;
    
    END;
CLOSE dpt_cur;
DEALLOCATE dpt_cur;
GO