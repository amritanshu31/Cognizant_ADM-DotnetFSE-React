select e.firstname, e.lastname, e.salary from employee e
join department d on e.workdept=d.deptno where d.location  = "New York"
order by e.firstname;
go