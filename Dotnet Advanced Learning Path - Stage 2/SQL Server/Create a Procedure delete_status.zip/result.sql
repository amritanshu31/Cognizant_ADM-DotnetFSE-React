CREATE PROCEDURE delete_status
@status_id int
as
IF EXISTS (SELECT * FROM agent WHERE id = @status_id)
    insert into status_error_log(error_msg) values("child records existing in claims table");
else IF EXISTS (SELECT * FROM address WHERE id = @status_id)
    insert into status_error_log(error_msg) values("child records existing in claims table");
else IF EXISTS (SELECT * FROM customer WHERE id = @status_id)
    insert into status_error_log_table(error_msg) values("child records existing in claims table");
else IF EXISTS (SELECT * FROM insurance_company WHERE id = @status_id)
    insert into status_error_log_table(error_msg) values("child records existing in claims table");
else IF EXISTS (SELECT * FROM policy WHERE id = @status_id)
    insert into status_error_log(error_msg) values("child records existing in claims table");
else IF EXISTS (SELECT * FROM customer_policy WHERE id = @status_id)
    insert into status_error_log(error_msg) values("child records existing in claims table");
else IF EXISTS (SELECT * FROM claims WHERE id = @status_id)
    insert into status_error_log(error_msg) values("child records existing in claims table");
else
    delete from status where id=@status_id;
GO