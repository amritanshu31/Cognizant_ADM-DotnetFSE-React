Create procedure EmployeeCount
(
@deptno char(3),
@total_employees int output
)
As
Begin
 select @total_employees = count(empno) from employee where workdept = @deptno
Return @total_employees
End
Go