create proc AvailableDepartments as
begin
select deptname as Name from department
end 
go