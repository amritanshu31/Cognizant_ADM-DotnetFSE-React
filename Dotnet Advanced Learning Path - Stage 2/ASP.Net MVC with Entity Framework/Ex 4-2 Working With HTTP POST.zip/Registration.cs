//THIS IS FOR REFERENCE ONLY. YOU ARE NOT REQUIRED TO MAKE ANY CHANGES HERE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ASP_App1.Models
{
    public class Registration
    {
        public String CustomerName { get; set; }
        public long PhoneNumber { get; set; }
        public string VehicleNo { get; set; }
        public string City { get; set; }
        public string VehicleModel { get; set; }
        public string ServiceType { get; set; }

    }
}