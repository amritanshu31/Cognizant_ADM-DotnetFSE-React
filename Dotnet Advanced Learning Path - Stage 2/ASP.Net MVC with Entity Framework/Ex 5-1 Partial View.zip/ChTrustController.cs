
using System;

using System.Collections.Generic;

using System.Linq;

using System.Web;

using System.Web.Mvc;


namespace ASP_App1.Controllers //DO NOT change the namespace name

{

  public class ChTrustController : Controller //DO NOT change the class name

  {

//Provide your program input(if any) in the field placed below your code editor before Compile & Run.

//Make sure you have evaluated your program before submitting the assessment.

 


    // Implement 'ChTrust' action

    

    // Implement 'HeaderNavBar' action

    

    // Implement 'FooterNavBar' action

     public ActionResult ChTrust()

    {

      return View();

    }

    public PartialViewResult _HeaderNavBar()

    {

      return PartialView();

    }

    public PartialViewResult _FooterNavBar()

    {

      return PartialView();

    }

    

  }

}