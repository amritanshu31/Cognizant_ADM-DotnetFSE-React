using System;

using System.Collections.Generic;

using System.Linq;

using System.Web;

using System.Web.Mvc;


namespace ASP_App1.Controllers //DO NOT change the namespace name

{

  

  

  [RoutePrefix("flipkart")]

  public class HomeController : Controller

  {

    [Route("info")]

    public ActionResult About()

    {

      

      ViewBag.Business = "Flipkart";

      ViewBag.Type = "E-commerce";

      ViewBag.Founded = 2007;

      ViewBag.Website = "www.flipkart.com";

      return View();

    }

  }

}


