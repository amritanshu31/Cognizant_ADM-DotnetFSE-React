using ASP_EF_App1.DAL;


using ASP_EF_App1.Models;


using System;


using System.Collections.Generic;


using System.Linq;


using System.Web;


using System.Web.Mvc;



namespace ASP_EF_App1.Controllers //DO NOT change the namespace name


{


 public class ProjectController : Controller //DO NOT change the class name


 {


  public ActionResult ProjectDetail()


  {


   return View("AddProjectDetails");



  }// Implement 'ProjectDetail' action


  [HttpPost]


  public ActionResult ProjectDetail(Project project)


  {


   project.ProjectId = 1;


   var context = new ProjectContext();


   context.Projects.Add(project);


   context.SaveChanges();


   return View("ViewProjectDetails",project);



  }


 }


}

