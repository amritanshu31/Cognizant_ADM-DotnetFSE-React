//THIS IS FOR REFERENCE ONLY. YOU ARE NOT REQUIRED TO MAKE ANY CHANGES HERE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1           //DO NOT Change the namespace name 
{
   public class Book //DO NOT Change the class name
    {
       public int BookId { get; set; }
        public String BookName { get; set; }
        public String BookAuthor { get; set; }
        public String BookGenre { get; set; }
        public double BookPrice { get; set; }

    }
}
