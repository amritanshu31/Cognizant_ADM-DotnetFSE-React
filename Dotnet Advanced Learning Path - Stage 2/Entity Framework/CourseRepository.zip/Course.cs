//THIS CLASS IS FOR REFERENCE. YOU NEED NOT CHANGE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exercise1   //DO NOT Change the namespace name
{
  public  class Course   //DO NOT Change the class name
    {
        
        public int CourseId { get; set; }
        public String CourseName { get; set; }
        public double CourseFee { get; set; }
        public int Duration { get; set; }
        public String InstructorName { get; set; }
    }
}