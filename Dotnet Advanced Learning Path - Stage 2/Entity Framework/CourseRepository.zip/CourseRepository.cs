using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace Exercise1             //DO NOT Change the namespace name
{
   public class CourseRepository      //DO NOT Change the class name
    {
        //DO NOT Change the variable or method signature. Add only the required code inside the method.
        
        private CourseContext context;
        
        public CourseRepository(CourseContext context)
        {
            //Implement code here
            this.context=context;
        }
        
        public IList<Course> GetCourseList()
        {
            //Implement code here
            
            DbSet<Course> c=context.Courses;
            IList<Course> courses=c.ToList<Course>();
            return courses;
        }

        public Course GetCourseByID(int courseId)
        {
             //Implement code here
             DbSet<Course> c=context.Courses;
             Course cos=c.Find(courseId);
             return cos;
        }

        public void InsertCourse(Course course)
        {
             //Implement code here
             context.Courses.Add(course);
             Console.WriteLine("Details Added Successfully");
             context.SaveChanges();
        }

        public Course UpdateCourseFee(int id, double fee)
        {
             //Implement code here
             DbSet<Course> c = context.Courses;
             Course cs=c.Find(id);
             if(cs!=null)
             {
                 cs.CourseFee=fee;
                 if(context.SaveChanges()>0)
                 {
                     Console.WriteLine("updated Successfully");
                 }
             }
             return cs;
        }
    }
}