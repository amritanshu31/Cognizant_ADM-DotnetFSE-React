using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentManagement               //DO NOT Change the namespace name
{
    public class Program              //DO NOT Change the class name
    {
        public static void Main(string[] args)
        {
            
            
            Student s= new Student();
            
            Console.WriteLine("Enter Student Id");
            s.StudentId = Convert.ToInt32(Console.ReadLine());
            
             Console.WriteLine("Enter Student Name");
            s.StudentName = Console.ReadLine();
            
             Console.WriteLine("Enter Department");
            s.Department = Console.ReadLine();
            
             Console.WriteLine("Enter Enrollment Date");
             string[] dateextraction = Console.ReadLine().Split('-');
            DateTime dt=new DateTime(int.Parse(dateextraction[2]),int.Parse(dateextraction[1]),int.Parse(dateextraction[0]));
            s.EnrolledDate=dt;
            
             Console.WriteLine("Enter PhoneNumber");
            s.PhoneNumber = long.Parse(Console.ReadLine());
            
            Program p = new Program();
            p.AddStudent(s);
            
            
            //Implement the code here
        }
        
        public void AddStudent(Student student){       //Do not change the method signature
            
            CollegeContext context=new CollegeContext();
          
            
            context.Students.Add(student);
            context.SaveChanges();
            Console.WriteLine("Details Added Successfully");
            //Add the student details to database. 
        }
    }
}
