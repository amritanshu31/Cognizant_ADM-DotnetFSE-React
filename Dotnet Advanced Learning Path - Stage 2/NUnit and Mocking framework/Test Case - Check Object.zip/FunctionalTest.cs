using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace DemoAppCore
{
    //Add required NUnit test attribute
    [TestFixture]
    class FunctionalTest
    {
        //Add required test methods
        [Test]
        public void e1_test(){
            Employee e = Program.e1;
            Assert.That(e==null);
        }
        [Test]
        public void EnrollEmployeeTest(){
            Employee e1 = Program.EnrollEmployee();
            Assert.NotNull(e1);
        }
        [Test]
        public void get_Name_Test(){
            Employee e2 = Program.EnrollEmployee();
            Assert.That(e2.Name, Is.EqualTo("Tom"));
        }
        [Test]
        public void get_Id_Test(){
            Employee e3 = Program.EnrollEmployee();
            Assert.That(e3.Id, Is.EqualTo("A1234"));
        }
    }
}