using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace DemoAppCore
{
    //Add required NUnit test attribute
    [TestFixture]
    class FunctionalTest
    {
        //Add required test methods
        [Test]
        public void Checknull_test(){
            var x = Program.names;
            Assert.That(x,Is.EqualTo(null));
        }
        [Test]
        public void FinalList_test1(){
            var x = Program.FinalList();
            CollectionAssert.AllItemsAreUnique(x);
        }
        [Test]
        public void value()
        {
           List<string> names=new List<string>();
           names.Add("Peter");
           names.Add("Sally");
           names.Add("Nimmi");
           CollectionAssert.AllItemsAreUnique(names);
        
        }
        
    }
}