//THIS IS FOR REFERENCE ONLY. YOU NEED NOT MAKE ANY CHANGES HERE
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoAppCore
{
    public class Program
    {
        public static int AddNumbers(int num1,int num2)
        {
            return num1+num2;
        }
        public static int SubNumbers(int num1,int num2)
        {
            return num1-num2;
        }
        public static int MulNumbers(int num1,int num2)
        {
            return num1*num2;
        }
        public static int DivNumbers(int num1,int num2)
        {
            return num1/num2;
        }
    }
}
