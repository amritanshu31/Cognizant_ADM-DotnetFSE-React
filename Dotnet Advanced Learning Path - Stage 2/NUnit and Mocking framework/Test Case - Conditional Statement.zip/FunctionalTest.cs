using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;

namespace DemoAppCore
{
    //Add required NUnit test attribute
    [TestFixture]
    class FunctionalTest
    {
        //Add required test methods
        [Test]
        [TestCase(42,"pass")]
        [TestCase(20,"fail")]
        [TestCase(40,"pass")]
        public static void CalculateGrade(int a, string b)
        {
            var x = Program.CalculateGrade(a);
            Assert.That(x, Is.EqualTo(b).IgnoreCase);
        }
        
    }
}