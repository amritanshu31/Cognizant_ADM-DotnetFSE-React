import logo from './logo.svg';
import './App.css';
import { CalculateScore } from './Components/CalculateScore';

function App() {
  return (
    <div>
      <CalculateScore Name={"Vivek"}
      School={"MMMUT"}
      total={460}
      goal={5}
      />
    </div>
  );
}

export default App;
