import React, {Component} from 'react';
export class Home extends React.Component{
    render(){
        return(
          <div>
            <h3>Welcome to the Home Page of Student Management Portal</h3>
        </div>
        );
    }
}
// import React from 'react'

// const Home = () => {
//   return (
//     <div><h3>Welcome to the Home Page of Student Management Portal</h3></div>
//   )
// }

// export default Home