import React, {Component} from 'react';
export class Contact extends React.Component{
    render(){
        return(
            <div>
              <h3>Welcome to the Home Page of Student Management Portal</h3>
          </div>
          );
    }

}

// import React from 'react'

// const Contact = () => {
//   return (
//     <div><h3>Welcome to the Home Page of Student Management Portal</h3></div>
//   )
// }

// export default Contact