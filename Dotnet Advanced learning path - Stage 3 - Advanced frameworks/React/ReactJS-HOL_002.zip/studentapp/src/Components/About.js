import React, {Component} from 'react';
export class About extends React.Component{
    render(){
        return(
        <div>
            <h3>Welcome to the Home Page of Student Management Portal</h3>
        </div>
        );
    }
}

// import React from 'react'

// const About = () => {
//   return (
//     <div><h3>Welcome to the Home Page of Student Management Portal</h3></div>
//   )
// }

// export default About
