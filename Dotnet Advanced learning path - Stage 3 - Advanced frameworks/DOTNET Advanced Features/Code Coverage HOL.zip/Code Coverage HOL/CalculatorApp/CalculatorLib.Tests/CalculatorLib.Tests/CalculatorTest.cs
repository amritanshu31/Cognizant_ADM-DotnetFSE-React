﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalcularorLib;

namespace CalculatorLib.Tests
{
    [TestFixture]
    public class CalculatorTest
    {
        [TestCase]
        public void Add_When_Both_Inputs_GreaterThanZero_Returns_ExpectedResult()
        {
            //Arrange
            
            Calculator calculator = new Calculator();

            int firstNo = 30;
            int secondNo = 20;

            int expectedResult = 50;

            int actualResult;

            //Act
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
        [TestCase]
        public void Add_When_firstnum_is_less_thanzero_Returns_ExpectedResult()
        {
            //Arrange

            Calculator calculator = new Calculator();

            int firstNo = -30;
            int secondNo = 20;

            int expectedResult = -2;

            int actualResult;

            //Act
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
        [TestCase]
        public void Add_When_secondnum_is_less_thanzero_Returns_ExpectedResult()
        {
            //Arrange

            Calculator calculator = new Calculator();

            int firstNo = 30;
            int secondNo = -20;

            int expectedResult = -1;

            int actualResult;

            //Act
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
        [TestCase]
        public void Add_When_Both_Inputs_lessThanZero_Returns_ExpectedResult()
        {
            //Arrange

            Calculator calculator = new Calculator();

            int firstNo = -30;
            int secondNo = -20;

            int expectedResult = 0;

            int actualResult;

            //Act
            actualResult = calculator.Add(firstNo, secondNo);

            //Assert

            Assert.That(expectedResult == actualResult, "Verify the add method logic");
        }
    }
}
