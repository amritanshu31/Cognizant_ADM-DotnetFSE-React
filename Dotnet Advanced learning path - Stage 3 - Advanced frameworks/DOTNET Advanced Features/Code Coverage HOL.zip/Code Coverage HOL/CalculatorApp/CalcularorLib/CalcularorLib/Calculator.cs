﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalcularorLib
{
    public class Calculator
    {
        public int Add(int firstNum, int secondNum)
        {
            int result = 0;
            if (firstNum > 0 && secondNum > 0) { result = firstNum + secondNum; }
            else if (firstNum > 0 && secondNum <= 0) { result = -1; }
            else if (firstNum <= 0 && secondNum > 0) { result = -2; }
            else if(firstNum <= 0 && secondNum <= 0) { result = 0; }
            return result;
        }
    }
}
