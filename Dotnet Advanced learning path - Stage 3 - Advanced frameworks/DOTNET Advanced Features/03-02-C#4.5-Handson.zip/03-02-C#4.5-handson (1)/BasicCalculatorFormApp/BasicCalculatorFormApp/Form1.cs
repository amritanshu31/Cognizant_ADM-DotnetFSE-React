﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCalculatorFormApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void calculateButton1_Click(object sender, EventArgs e)
        {
            double number1, number2, result;
            if(!double.TryParse(textBox2.Text, out number2)|| textBox2.Text.Length==0||textBox1.Text.Length==0 || !double.TryParse(textBox1.Text, out number1))
            {
                MessageBox.Show("Please enter valid input for the operands");
            }
            number1 = Convert.ToDouble(textBox1.Text);
            number2 = Convert.ToDouble(textBox2.Text);
            if (radioAddButton1.Checked)
            {
                result = number1 + number2;
                MessageBox.Show(Convert.ToString(result));
            }
            if (radioSubButton2.Checked)
            {
                result = number1 - number2;
                MessageBox.Show(Convert.ToString(result));
            }
            if (radioMulButton3.Checked)
            {
                result = number1 * number2;
                MessageBox.Show(Convert.ToString(result));
            }
            if (radioDivButton4.Checked)
            {
                try
                {
                    result = number1 / number2;
                    MessageBox.Show(Convert.ToString(result));
                }
                catch(Exception)
                {
                    MessageBox.Show("Could not divide by zero");
                }
            }
            
        }
    }
}
