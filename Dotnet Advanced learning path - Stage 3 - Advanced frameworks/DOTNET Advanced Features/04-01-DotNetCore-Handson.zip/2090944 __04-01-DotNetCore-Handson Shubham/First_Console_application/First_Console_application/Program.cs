﻿using System;

using System.Threading.Tasks;

namespace First_Console_application
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello world!!");

            Console.ReadKey();
        }
    }
}
